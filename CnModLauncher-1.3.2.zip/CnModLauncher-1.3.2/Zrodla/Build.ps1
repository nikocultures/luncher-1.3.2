param([Parameter(Mandatory=$true)][string]$OriginalExe)
$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) { throw '.NET Framework C# compiler is missing.' }
$buildDir = Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Path $buildDir -Force | Out-Null
$package = Join-Path $buildDir 'Mono.Cecil.0.11.6.zip'
$cecilDir = Join-Path $buildDir 'Mono.Cecil.0.11.6'
if (-not (Test-Path -LiteralPath $cecilDir)) {
    Invoke-WebRequest -Uri 'https://api.nuget.org/v3-flatcontainer/mono.cecil/0.11.6/mono.cecil.0.11.6.nupkg' -OutFile $package
    Expand-Archive -LiteralPath $package -DestinationPath $cecilDir
}
$cecil = Join-Path $buildDir 'Mono.Cecil.dll'
Copy-Item -LiteralPath (Join-Path $cecilDir 'lib\net40\Mono.Cecil.dll') -Destination $cecil
$runtime = Join-Path $buildDir 'CnModLauncher.Runtime.dll'
$patcher = Join-Path $buildDir 'PatchLauncher.exe'
& $compiler /nologo /target:library "/out:$runtime" (Join-Path $PSScriptRoot 'CnModRuntime.cs')
if ($LASTEXITCODE -ne 0) { throw 'Runtime compilation failed.' }
& $compiler /nologo "/out:$patcher" "/reference:$cecil" "/reference:$runtime" (Join-Path $PSScriptRoot 'PatchLauncher.cs')
if ($LASTEXITCODE -ne 0) { throw 'Patcher compilation failed.' }
$destination = Split-Path $PSScriptRoot -Parent
& $patcher (Resolve-Path -LiteralPath $OriginalExe).Path $runtime (Join-Path $destination 'CnModLauncher.exe')
if ($LASTEXITCODE -ne 0) { throw 'Launcher patch failed.' }
Copy-Item -LiteralPath $runtime -Destination $destination
Write-Output 'Launcher rebuilt. OriginalExe was read only.'
