using System;
using System.IO;
using System.Diagnostics;

namespace CnMod132 {
    public static class Runtime {
        public const string GameFile = "Culturesnation Mod.v1.3.2.schoolfix.exe";
        public static string FindRoot(string baseDirectory) {
            string settings = Path.Combine(baseDirectory, "CnModLauncher.game-path.txt");
            if (File.Exists(settings)) {
                string configured = File.ReadAllText(settings).Trim();
                if (configured.Length > 0) {
                    configured = configured.Replace("%DESKTOP%", Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));
                    configured = Environment.ExpandEnvironmentVariables(configured);
                    if (!Path.IsPathRooted(configured)) configured = Path.Combine(baseDirectory, configured);
                    return Validate(configured);
                }
            }
            string[] paths = {
                Path.Combine(baseDirectory, "runtime", "CnMod 1.3.2"),
                Path.Combine(baseDirectory, "runtime"),
                baseDirectory,
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "CnMod 1.3.2")
            };
            foreach (string path in paths)
                if (File.Exists(Path.Combine(path, GameFile)) && Directory.Exists(Path.Combine(path, "CnModMaps")))
                    return Validate(path);
            throw new DirectoryNotFoundException("Nie znaleziono CnMod 1.3.2. Wpisz folder gry do pliku CnModLauncher.game-path.txt obok launchera.");
        }
        private static string Validate(string path) {
            string full = Path.GetFullPath(path);
            if (!File.Exists(Path.Combine(full, GameFile)) || !Directory.Exists(Path.Combine(full, "CnModMaps")))
                throw new DirectoryNotFoundException("Folder CnMod 1.3.2 musi zawierać " + GameFile + " oraz CnModMaps: " + full);
            return full;
        }
        public static string FindPython() {
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string[] paths = {
                Path.Combine(local, "Programs", "Python", "Python312", "python.exe"),
                Path.Combine(local, "Programs", "Python", "Python313", "python.exe"),
                Path.Combine(local, "Programs", "Python", "Python314", "python.exe"),
                Path.Combine(local, "Programs", "Python", "Python311", "python.exe"),
                Path.Combine(local, "Programs", "Python", "Python310", "python.exe"),
                "python.exe"
            };
            foreach (string path in paths) {
                try {
                    ProcessStartInfo info = new ProcessStartInfo(path, "-c \"import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)\"");
                    info.UseShellExecute = false;
                    info.CreateNoWindow = true;
                    using (Process process = Process.Start(info)) {
                        if (!process.WaitForExit(5000)) { try { process.Kill(); } catch {} continue; }
                        if (process.ExitCode == 0) return path;
                    }
                } catch {}
            }
            throw new InvalidOperationException("Wymagany jest Python 3.10 lub nowszy. Zainstaluj go z opcją dodania do PATH.");
        }
    }
}
