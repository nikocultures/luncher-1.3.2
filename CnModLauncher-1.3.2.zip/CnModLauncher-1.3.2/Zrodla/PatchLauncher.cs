using System;
using System.IO;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class PatchLauncher {
    static void Main(string[] args) {
        using (AssemblyDefinition asm = AssemblyDefinition.ReadAssembly(args[0]))
        using (AssemblyDefinition helper = AssemblyDefinition.ReadAssembly(args[1])) {
            if (asm.Name.HasPublicKey) throw new Exception("Unexpected signed launcher");
            ModuleDefinition module = asm.MainModule;
            TypeDefinition form = module.Types.Single(t => t.FullName == "CnModNativeLauncher.LauncherForm");
            TypeDefinition runtime = helper.MainModule.Types.Single(t => t.FullName == "CnMod132.Runtime");
            MethodDefinition root = form.Methods.Single(m => m.Name == "FindRuntime");
            root.Body.Instructions.Clear(); root.Body.Variables.Clear(); root.Body.ExceptionHandlers.Clear();
            ILProcessor il = root.Body.GetILProcessor();
            il.Append(il.Create(OpCodes.Ldarg_0));
            il.Append(il.Create(OpCodes.Ldfld, form.Fields.Single(f => f.Name == "baseDirectory")));
            il.Append(il.Create(OpCodes.Call, module.ImportReference(runtime.Methods.Single(m => m.Name == "FindRoot"))));
            il.Append(il.Create(OpCodes.Ret));
            MethodDefinition python = form.Methods.Single(m => m.Name == "FindPython");
            python.Body.Instructions.Clear(); python.Body.Variables.Clear(); python.Body.ExceptionHandlers.Clear();
            il = python.Body.GetILProcessor();
            il.Append(il.Create(OpCodes.Call, module.ImportReference(runtime.Methods.Single(m => m.Name == "FindPython"))));
            il.Append(il.Create(OpCodes.Ret));
            int gameChanges = 0;
            foreach (TypeDefinition type in module.Types) {
                foreach (MethodDefinition method in type.Methods.Where(m => m.HasBody)) {
                    foreach (Instruction instruction in method.Body.Instructions) {
                        if (instruction.OpCode != OpCodes.Ldstr) continue;
                        string value = (string)instruction.Operand;
                        if (value == "Culturesnation Mod.exe") { instruction.Operand = CnMod132.Runtime.GameFile; gameChanges++; }
                        else if (value == "Culturesnation Mod") instruction.Operand = Path.GetFileNameWithoutExtension(CnMod132.Runtime.GameFile);
                        else if (value == "graphics" && method.Name == "SaveGraphicsSettings") instruction.Operand = "graphics\\1.3.2";
                        else instruction.Operand = value.Replace("1.3.1", "1.3.2");
                    }
                }
            }
            if (gameChanges != 2) throw new Exception("Unexpected number of game filename references: " + gameChanges);
            asm.Name.Version = new Version(1,0,1,0);
            foreach (CustomAttribute attribute in asm.CustomAttributes) {
                for (int i=0; i<attribute.ConstructorArguments.Count; i++) {
                    CustomAttributeArgument a=attribute.ConstructorArguments[i];
                    if (a.Value is string) attribute.ConstructorArguments[i] = new CustomAttributeArgument(a.Type, ((string)a.Value).Replace("1.3.1", "1.3.2"));
                }
            }
            asm.Write(args[2]);
            byte[] binary = File.ReadAllBytes(args[2]);
            byte[] oldComment = System.Text.Encoding.Unicode.GetBytes("Launcher map i frakcji dla CnMod 1.3.1");
            byte[] newComment = System.Text.Encoding.Unicode.GetBytes("Launcher map i frakcji dla CnMod 1.3.2");
            for (int i=0; i <= binary.Length-oldComment.Length; i++) {
                bool match=true;
                for (int j=0;j<oldComment.Length;j++) if(binary[i+j]!=oldComment[j]) {match=false;break;}
                if(match) Buffer.BlockCopy(newComment,0,binary,i,newComment.Length);
            }
            File.WriteAllBytes(args[2],binary);
            Console.WriteLine("Patched launcher; game references: " + gameChanges + "; embedded resources preserved: " + module.Resources.Count);
        }
    }
}
